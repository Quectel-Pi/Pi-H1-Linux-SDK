#include <inttypes.h>
#include <stdio.h>  
#include <stdlib.h>  
#include <stdint.h>  
#include <string.h>  
#include <fcntl.h>
#include <unistd.h>
#include <endian.h> 
#include <errno.h> 
#include <sys/sendfile.h> 

#define SPARSE_HEADER_MAGIC 0xed26ff3a
#define SPARSE_CHUNK_TYPE_RAW 0xCAC1  
#define SPARSE_CHUNK_TYPE_FILL 0xCAC2 
#define SPARSE_CHUNK_TYPE_ZERO 0xCAC3 

typedef struct sparse_header
{
  uint32_t magic;         /* 0xed26ff3a */
  uint16_t major_version; /* (0x1) - reject images with higher major versions */
  uint16_t minor_version; /* (0x0) - allow images with higer minor versions */
  uint16_t file_hdr_sz;   /* 28 bytes for first revision of the file format */
  uint16_t chunk_hdr_sz;  /* 12 bytes for first revision of the file format */
  uint32_t blk_sz;       /* block size in bytes, must be a multiple of 4 (4096) */
  uint32_t total_blks;   /* total blocks in the non-sparse output image */
  uint32_t total_chunks; /* total chunks in the sparse input image */
  uint32_t image_checksum; /* CRC32 checksum of the original data, counting "don't care" */
  /* as 0. Standard 802.3 polynomial, use a Public Domain */
  /* table implementation */
} sparse_header_t;

typedef struct chunk_header {
  uint16_t chunk_type; /* 0xCAC1 -> raw; 0xCAC2 -> fill; 0xCAC3 -> don't care */
  uint16_t reserved1;
  uint32_t chunk_sz; /* in blocks in output image */
  uint32_t total_sz; /* in bytes of chunk input file including chunk header and data */
} chunk_header_t;

static uint8_t data_buf[64*4096];

int main(int argc, char *argv[])
{
    sparse_header_t sparse_header;
    int in_fd, out_fd;
    uint64_t in_image_sz = 0;
    uint64_t out_image_sz = 0;
    uint32_t m;

    char filename[256];

    strcpy(filename, argv[1]);
    in_fd = open(filename, O_RDONLY);
    if (in_fd == -1) {
        printf("open %s fail! errno: %d (%s)\n", filename, errno, strerror(errno));
        return -1;
    }
    strcat(filename, ".raw");
    out_fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (out_fd == -1) {
        printf("open %s fail! errno: %d (%s)\n", filename, errno, strerror(errno));
        close(in_fd);
        return -1;
    }

    if (read(in_fd, &sparse_header, sizeof(sparse_header_t)) != sizeof(sparse_header_t)) {
        printf("%s read sparse_header failed\n", __func__);
        goto out;
    }

    printf("sparse_header->magic = %0x\n", sparse_header.magic);
    if (sparse_header.magic != SPARSE_HEADER_MAGIC)
        goto out;
    printf("sparse_header->major_version = %0x\n", sparse_header.major_version);
    printf("sparse_header->minor_version = %0x\n", sparse_header.minor_version);
    printf("sparse_header->file_hdr_sz = %d\n", sparse_header.file_hdr_sz);
    printf("sparse_header->chunk_hdr_sz = %d\n", sparse_header.chunk_hdr_sz);
    printf("sparse_header->blk_sz = %d\n", sparse_header.blk_sz);
    printf("sparse_header->total_blks = %d\n", sparse_header.total_blks);
    printf("sparse_header->total_chunks = %d\n", sparse_header.total_chunks);
    printf("sparse_header->image_checksum = %d\n", sparse_header.image_checksum);

    in_image_sz = sparse_header.blk_sz * sparse_header.total_blks;

    for (m = 0; m < (sparse_header.total_chunks); m++) {
        chunk_header_t chunk_header;

        if (read(in_fd, &chunk_header, sizeof(chunk_header)) != sizeof(chunk_header)) {
            printf("%s read chunk_header failed\n", __func__);
            goto out;
        }
        printf("chunk_header[%d]: ", m);
        printf("chunk_type = %0x ", chunk_header.chunk_type);
        printf("reserved1 = %0x ", chunk_header.reserved1);
        printf("chunk_sz = %d ", chunk_header.chunk_sz);
        printf("total_sz = %d\n", chunk_header.total_sz);

        if (chunk_header.chunk_type == SPARSE_CHUNK_TYPE_RAW) {
            uint32_t data_sz = chunk_header.chunk_sz * sparse_header.blk_sz;
        
             if (chunk_header.total_sz != (data_sz + 12))
                goto out;

            while (data_sz > 0) {
                uint32_t cur_sz = data_sz;
                if (cur_sz > sizeof(data_buf))
                    cur_sz = sizeof(data_buf);

                if (read(in_fd, data_buf, cur_sz) != cur_sz) {
                    printf("%s read raw data failed\n", __func__);
                    goto out;
                }
                if (write(out_fd, data_buf, cur_sz) != cur_sz) {
                    printf("%s write raw data failed\n", __func__);
                    goto out;
                }
                data_sz -= cur_sz;
                out_image_sz += cur_sz;
            }
        }
        else if (chunk_header.chunk_type == SPARSE_CHUNK_TYPE_FILL) {
            uint32_t data_sz = chunk_header.chunk_sz * sparse_header.blk_sz;
            uint32_t fillValue;
            uint32_t i;
                
            if (chunk_header.total_sz != 16)
                goto out;

            if (read(in_fd, &fillValue, 4) != 4) {
                printf("%s read fill data failed\n", __func__);
                goto out;
            }
            for (i = 0; i < (sparse_header.blk_sz/4); i++)
                ((uint32_t *)data_buf)[i] = fillValue;

            while (data_sz > 0) {
                if (write(out_fd, data_buf, sparse_header.blk_sz) != sparse_header.blk_sz) {
                    printf("write fill fail, errno: %d (%s)\n", errno, strerror(errno));
                    goto out;
                }
                data_sz -= sparse_header.blk_sz;
                out_image_sz += sparse_header.blk_sz;
            }
        }
        else if (chunk_header.chunk_type == SPARSE_CHUNK_TYPE_ZERO) {
            uint32_t data_sz = chunk_header.chunk_sz * sparse_header.blk_sz;

            if (chunk_header.total_sz != 12)
                goto out;

            memset(data_buf, 0x00, sparse_header.blk_sz);
            while (data_sz > 0) {
                if (write(out_fd, data_buf, sparse_header.blk_sz) != sparse_header.blk_sz) {
                    printf("write fail, errno: %d (%s)\n", errno, strerror(errno));
                    goto out;
                }
                data_sz -= sparse_header.blk_sz;
                out_image_sz += sparse_header.blk_sz;
            }
        }
        else {
            printf("unknow trunch type 0x%0x\n", chunk_header.chunk_type);
            goto out;
        }
    }

out:
    printf("in_image_sz=%"PRIu64", out_image_sz=%"PRIu64"\n", in_image_sz, out_image_sz);
    close(in_fd);
    close(out_fd);

    return 0;
}
