#include "QMIThread.h"

#include <nanomsg/nn.h>
#include <ccsp/ipc_msg.h>

#define RETURN_ERROR -1
#define RETURN_OK 0
#define CcspTraceInfo(msg) printf msg

/** Cellular Device Open Status */
typedef enum _CellularDeviceOpenStatus_t
{
   DEVICE_OPEN_STATUS_NOT_READY = 1,
   DEVICE_OPEN_STATUS_INPROGRESS,
   DEVICE_OPEN_STATUS_READY,

}CellularDeviceOpenStatus_t;

#define DML_LTE_IFACE_PATH                "Device.Cellular.Interface.1"
#define WAN_DBUS_PATH                     "/com/cisco/spvtg/ccsp/wanmanager"
#define WAN_COMPONENT_NAME                "eRT.com.cisco.spvtg.ccsp.wanmanager"
#define DML_NO_OF_INTERFACE_ENTRIES       "Device.X_RDK_WanManager.CPEInterfaceNumberOfEntries"                      
#define DML_IFTABLE_IFACE_NAME            "Device.X_RDK_WanManager.CPEInterface.%d.Name"
#define DML_IFTABLE_IFACE_LINK_STATUS     "Device.X_RDK_WanManager.CPEInterface.%d.Wan.LinkStatus"
#define DML_IFTABLE_IFACE_WAN_NAME        "Device.X_RDK_WanManager.CPEInterface.%d.Wan.Name"
#define DML_IFTABLE_IFACE_WAN_STATUS        "Device.X_RDK_WanManager.CPEInterface.%d.Wan.Status"
#define DML_IFTABLE_IFACE_PHY_STATUS      "Device.X_RDK_WanManager.CPEInterface.%d.Phy.Status"
#define DML_IFTABLE_IFACE_PHY_PATH        "Device.X_RDK_WanManager.CPEInterface.%d.Phy.Path"
#define UP_STR                            "Up"
#define DOWN_STR                          "Down"

//#define DML_GETV "dmcli eRT getv "
//#define DML_SETV "dmcli eRT setv "
#define DML_GETV "rbuscli getv "
#define DML_SETV "rbuscli setv "

static int wan_index = -1;
static char rdk_shell_cmd[512];
static int rdk_run_cmd(const char *cmd) {
    int result;
    CcspTraceInfo(("%s\n", cmd));
    result = system(cmd);
    //if (result != 0)
    //    CcspTraceInfo(("result: %d\n", result));
    return result;
}

static const char *ipv4Str(const uint32_t Address) {
    static char str[] = {"255.225.255.255"};
    uint8_t *ip = (uint8_t *)&Address;

    snprintf(str, sizeof(str), "%d.%d.%d.%d", ip[3], ip[2], ip[1], ip[0]);
    return str;
}

int CellularMgrGetLTEIfaceIndex ( char *wan_ifname )
{
    int index = wan_index;
    (void)wan_ifname;
    if (index == -1) {
        index = wan_index = 2;
        snprintf(rdk_shell_cmd, sizeof(rdk_shell_cmd), DML_GETV DML_IFTABLE_IFACE_NAME, index );
        rdk_run_cmd(rdk_shell_cmd);
    }
    return index;
}

void set_wan_ifname(char* wan_ifname,int index)
{
    (void)wan_ifname;
    (void)index;
    snprintf(rdk_shell_cmd, sizeof(rdk_shell_cmd), "psmcli get dmsb.wanmanager.if.%d.Name", index);
    rdk_run_cmd(rdk_shell_cmd);
}

int CellularMgrUpdatePhyStatus ( char *wan_ifname, CellularDeviceOpenStatus_t device_open_status )
{
    int index = -1;
    
    /*  Once we reach connected state , the correct WAN INTERFACE NAME is passed using MM APIS.
     *  Till modem moves to connected state , a hardcoded value will be used.
    */
    index = CellularMgrGetLTEIfaceIndex(wan_ifname);

    if( -1 == index )
    {
        return RETURN_ERROR;
    }

    set_wan_ifname(wan_ifname,index);

    // Send Phy Status for Interface
    if ( device_open_status == DEVICE_OPEN_STATUS_READY )
    {
        // Set Phy.Path
        snprintf( rdk_shell_cmd, sizeof(rdk_shell_cmd), DML_SETV DML_IFTABLE_IFACE_PHY_PATH " string %s", 
                index, DML_LTE_IFACE_PATH);
        rdk_run_cmd(rdk_shell_cmd);

        // Set Phy.Status
        snprintf( rdk_shell_cmd, sizeof(rdk_shell_cmd), DML_SETV DML_IFTABLE_IFACE_PHY_STATUS " string %s", 
                index, UP_STR);
        rdk_run_cmd(rdk_shell_cmd);
    }
    else
    {
        // Set Phy.Status
        snprintf( rdk_shell_cmd, sizeof(rdk_shell_cmd), DML_SETV DML_IFTABLE_IFACE_PHY_STATUS " string %s", 
                index, DOWN_STR);
        rdk_run_cmd(rdk_shell_cmd);
    }

    return RETURN_OK;
}

int CellularMgrUpdateLinkStatus ( char *wan_ifname, char *status )
{
    int index = -1;

    /*  Once we reach connected state , the correct WAN INTERFACE NAME is passed using MM APIS.
     *  Till modem moves to connected state , a hardcoded value will be used.
    */
    index = CellularMgrGetLTEIfaceIndex(wan_ifname);
    
    if( -1 == index )
    {
        return RETURN_ERROR;
    }

    snprintf(rdk_shell_cmd, sizeof(rdk_shell_cmd), DML_SETV DML_IFTABLE_IFACE_WAN_NAME " string %s", 
            index, wan_ifname);
    rdk_run_cmd(rdk_shell_cmd);

    snprintf( rdk_shell_cmd, sizeof(rdk_shell_cmd), DML_SETV DML_IFTABLE_IFACE_LINK_STATUS " string %s", 
            index, status);
    rdk_run_cmd(rdk_shell_cmd);

    return RETURN_OK;
}

int CellularMgr_Util_SendIPToWanMgr( const char *ifname, const IPV4_T *ipv4 )
{
    int sock   = -1;
    int sz_msg = 0;
    int bytes  = -1;

    if( ipv4 != NULL ) {
        CellularMgrUpdatePhyStatus((char *)ifname, DEVICE_OPEN_STATUS_READY);
        sleep(1); //see WanMgr_Policy_FixedModePolicy State_FixedWanInterfaceDown
        CellularMgrUpdateLinkStatus((char *)ifname, UP_STR);
    }
    else {
        CellularMgrUpdatePhyStatus((char *)ifname, DEVICE_OPEN_STATUS_NOT_READY);
        CellularMgrUpdateLinkStatus((char *)ifname, DOWN_STR);
    }

    if( ipv4 != NULL )
    {
        int conn   = -1;
        ipc_msg_payload_t msg;

        sz_msg = sizeof(ipc_msg_payload_t);
        memset(&msg, 0, sizeof(ipc_msg_payload_t));

        // message header
        msg.data.dhcpv4.addressAssigned = TRUE;
        msg.msg_type = DHCPC_STATE_CHANGED;

        // message body
        strncpy(msg.data.dhcpv4.ip, ipv4Str(ipv4->Address), sizeof(msg.data.dhcpv4.ip) - 1);
        strncpy(msg.data.dhcpv4.mask, ipv4Str(ipv4->Address), sizeof(msg.data.dhcpv4.mask) - 1);
        strncpy(msg.data.dhcpv4.gateway, ipv4Str(ipv4->Address), sizeof(msg.data.dhcpv4.gateway) - 1);
        strncpy(msg.data.dhcpv4.dnsServer, ipv4Str(ipv4->Address), sizeof(msg.data.dhcpv4.dnsServer) - 1);
        strncpy(msg.data.dhcpv4.dnsServer1, ipv4Str(ipv4->Address), sizeof(msg.data.dhcpv4.dnsServer1) - 1);
        strncpy(msg.data.dhcpv4.dhcpcInterface, ipv4Str(ipv4->Address), sizeof(msg.data.dhcpv4.dhcpcInterface) - 1);
        msg.data.dhcpv4.mtuAssigned = (ipv4->Mtu != 0) ? TRUE : FALSE;
        msg.data.dhcpv4.mtuSize = ipv4->Mtu;

        sock = nn_socket(AF_SP, NN_PUSH);
        if (sock < 0)
        {
            CcspTraceInfo(("%s %d: Failed to create the socket , error = [%d][%s]\n", __FUNCTION__, __LINE__, errno, strerror(errno)));
            return RETURN_ERROR;
        }

        conn = nn_connect(sock, WAN_MANAGER_ADDR);
        if (conn < 0)
        {
            CcspTraceInfo(("%s %d: Failed to connect to the wanmanager [%s], error= [%d][%s] \n", __FUNCTION__, __LINE__, WAN_MANAGER_ADDR,errno, strerror(errno)));
            nn_close(sock);
            return RETURN_ERROR;
        }

        CcspTraceInfo(("%s %d: Connected to server socket [%s] \n", __FUNCTION__, __LINE__,WAN_MANAGER_ADDR));

        bytes = nn_send(sock, (char *) &msg, sz_msg, 0);
        if (bytes < 0)
        {
            CcspTraceInfo(("%s %d: Failed to send data to the wanmanager error=[%d][%s] \n", __FUNCTION__, __LINE__,errno, strerror(errno)));
            nn_close(sock);
            return RETURN_ERROR;
        }

        CcspTraceInfo(("%s %d: Successfully send %d bytes to wanmanager \n", __FUNCTION__, __LINE__, bytes));
        nn_close(sock);

        sleep(3);
        snprintf( rdk_shell_cmd, sizeof(rdk_shell_cmd), DML_GETV DML_IFTABLE_IFACE_WAN_STATUS, 
                wan_index);
        rdk_run_cmd(rdk_shell_cmd);
        snprintf( rdk_shell_cmd, sizeof(rdk_shell_cmd), DML_GETV "Device.X_RDK_WanManager.CurrentActiveInterface");
        rdk_run_cmd(rdk_shell_cmd);
        rdk_run_cmd("syscfg get lan_ethernet_physical_ifnames");
        rdk_run_cmd("sysevent get wan_ifname");
    }

    return RETURN_OK;
}

/*
eth0 as WAN
psmcli set dmsb.wanmanager.if.1.Enable TRUE
psmcli set dmsb.wanmanager.if.2.Enable FALSE
syscfg set lan_ethernet_physical_ifnames eth1
syscfg commit
ipa xml category eth0 wan

psmcli get dmsb.wanmanager.if.1.Enable dmsb.wanmanager.if.2.Enable
    TRUE
    FALSE
syscfg get lan_ethernet_physical_ifnames
    eth1
brctl show brlan0
    bridge name     bridge id               STP enabled     interfaces
    brlan0          8000.00037f127c7c       no              ath0
                                                            ath1
                                                            ath14
                                                            ath15
                                                            ath2
                                                            ath3
                                                            eth1
                                                            rndis0

rbuscli get Device.Ethernet.Interface.1.Enable Device.Ethernet.Interface.1.Status Device.Ethernet.X_RDK_Interface.1.Upstream Device.X_RDK_WanManager.CPEInterface.1.Wan.Enable Device.X_RDK_WanManager.CPEInte
rface.1.Wan.Status Device.X_RDK_WanManager.CPEInterface.1.Wan.LinkStatus Device.X_RDK_WanManager.CPEInterface.1.Phy.Status Device.X_RDK_WanManager.CurrentActiveInterface
    Parameter  1:
                  Name  : Device.Ethernet.Interface.1.Enable
                  Type  : boolean
                  Value : 1
    Parameter  2:
                  Name  : Device.Ethernet.Interface.1.Status
                  Type  : string
                  Value : Up
    Parameter  3:
                  Name  : Device.Ethernet.X_RDK_Interface.1.Upstream
                  Type  : boolean
                  Value : 1
    Parameter  4:
                  Name  : Device.X_RDK_WanManager.CPEInterface.1.Wan.Enable
                  Type  : boolean
                  Value : 1
    Parameter  5:
                  Name  : Device.X_RDK_WanManager.CPEInterface.1.Wan.Status
                  Type  : string
                  Value : Up
    Parameter  6:
                  Name  : Device.X_RDK_WanManager.CPEInterface.1.Wan.LinkStatus
                  Type  : string
                  Value : Up
    Parameter  7:
                  Name  : Device.X_RDK_WanManager.CPEInterface.1.Phy.Status
                  Type  : string
                  Value : Up
    Parameter  8:
                  Name  : Device.X_RDK_WanManager.CurrentActiveInterface
                  Type  : string
                  Value : eth0

eth0 as LAN
psmcli set dmsb.wanmanager.if.1.Enable FALSE
psmcli set dmsb.wanmanager.if.2.Enable TRUE
syscfg set lan_ethernet_physical_ifnames eth0,eth1
syscfg commit
ipa xml category eth0 odu

psmcli get dmsb.wanmanager.if.1.Enable dmsb.wanmanager.if.2.Enable
    FALSE
    TRUE
syscfg get lan_ethernet_physical_ifnames
    eth0,eth1
brctl show brlan0
    bridge name     bridge id               STP enabled     interfaces
    brlan0          8000.00037f120808       no              ath0
                                                            ath1
                                                            ath14
                                                            ath15
                                                            ath2
                                                            ath3
                                                            eth0
                                                            eth1
                                                            rndis0

rbuscli get Device.Ethernet.Interface.2.Enable Device.Ethernet.Interface.2.Status Device.Cellular.Interface.1.Upstream Device.X_RDK_WanManager.CPEInterface.2.Wan.Enable Device.X_RDK_WanManager.CPEInterface.
2.Wan.Status Device.X_RDK_WanManager.CPEInterface.2.Wan.LinkStatus Device.X_RDK_WanManager.CPEInterface.2.Phy.Status Device.X_RDK_WanManager.CurrentActiveInterface
Parameter  1:
              Name  : Device.Ethernet.Interface.2.Enable
              Type  : boolean
              Value : 0
Parameter  2:
              Name  : Device.Ethernet.Interface.2.Status
              Type  : string
              Value : Down
Parameter  3:
              Name  : Device.Cellular.Interface.1.Upstream
              Type  : boolean
              Value : 1
Parameter  4:
              Name  : Device.X_RDK_WanManager.CPEInterface.2.Wan.Enable
              Type  : boolean
              Value : 1
Parameter  5:
              Name  : Device.X_RDK_WanManager.CPEInterface.2.Wan.Status
              Type  : string
              Value : Up
Parameter  6:
              Name  : Device.X_RDK_WanManager.CPEInterface.2.Wan.LinkStatus
              Type  : string
              Value : Up
Parameter  7:
              Name  : Device.X_RDK_WanManager.CPEInterface.2.Phy.Status
              Type  : string
              Value : Up
Parameter  8:
              Name  : Device.X_RDK_WanManager.CurrentActiveInterface
              Type  : string
              Value : qmapmux0.0
*/
