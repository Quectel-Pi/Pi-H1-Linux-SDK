#!/usr/bin/env python3

import datetime
import os
import socket
import struct
import sys
from threading import Thread

tag_magic = 95279527
tag_sync_version = 95270001
tag_open_file_for_write = 95270002

def sk_recv(sk, read_len = 1*1024*1024):
    recv_data = None
    try:
        recv_data = sk.recv(read_len)
    except KeyboardInterrupt as e:
        print(e)
    except Exception as e:
        print(e)
    return recv_data

def sk_recv_len(sk, need_len):
    read_len = 0
    recv_data = None
    while read_len < need_len:
        tmp_data = sk_recv(sk, need_len - read_len)
        if not tmp_data:
            break
        tmp_len = len(tmp_data)
        recv_data = recv_data + tmp_data if recv_data else tmp_data
        read_len = read_len + tmp_len

    if read_len < need_len:
        print("sk read %d / %d" % (read_len, need_len))
        recv_data = None
    return recv_data

def send_tag(sk, tag, length):
    data = struct.pack("III", tag_magic, tag, length)
    sk.sendall(data)

def send_tag_u32(sk, tag, u32):
    data = struct.pack("IIII", tag_magic, tag, 4, u32)
    sk.sendall(data)

def send_file(host, port, file):
    sk_err = False
    total_len = 0
    print("Sending file %s" % file)

    sk = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sk.settimeout(15)
    try:
        sk.connect((host, port))
        send_tag(sk, tag_open_file_for_write, len(file.encode("utf-8")))
        sk.sendall(file.encode("utf-8"))
        recv_data = sk_recv_len(sk, 16)
        if not recv_data:
            sk_err = True
        else:
            magic,tag,length,error = struct.unpack("IIII", recv_data)
            if magic != tag_magic or tag != tag_open_file_for_write or length != 4 or error != 0:
                print("magic: %d/%d, tag:%d/%d, length:%d error:%d" % (magic, tag_magic, tag, tag_open_file_for_write, length, error))
                sk_err = True
        if not sk_err:
            with open(file, "rb") as fi:
                while True:
                    send_data = fi.read(1*1024*1024)
                    if not send_data:
                        break
                    sk.sendall(send_data)
                    total_len += len(send_data)
    except KeyboardInterrupt as e:
        print(e)
        sk_err = True
    except Exception as e:
        print(e)
        sk_err = True

    sk.close()
    print("%d bytes send" % total_len)
    return sk_err

def send_dir(host, port, dir):
    sk_err = False
    for root, dirs, files in os.walk(dir):
        for file_name in files:
            sk_err = send_file(host, port, os.path.join(root, file_name))
            if sk_err:
                return sk_err
    return sk_err

def send_file_list(host, port, file_list):
    sk_err = False

    sk = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sk.settimeout(15)
    try:
        sk.connect((host, port))
        send_tag_u32(sk, tag_sync_version, 1)
        recv_data = sk_recv_len(sk, 16)
        if not recv_data:
            sk_err = True
        else:
            magic,tag,length,recv_version = struct.unpack("IIII", recv_data)
            if magic != tag_magic or tag != tag_sync_version or length != 4 or recv_version != 1:
                sk_err = True
    except KeyboardInterrupt as e:
        print(e)
        sk_err = True
    except Exception as e:
        print(e)
        sk_err = True

    if sk_err:
        sk.close()
        return 1
    sk.close()

    sk_err = False
    for file in file_list.split(" "):
        if not os.access(file, os.F_OK):
            continue
        elif os.path.isfile(file):
            sk_err = send_file(host, port, file)
        elif os.path.isdir(file):
            sk_err = send_dir(host, port, file)
        if sk_err:
            break

    return 1 if sk_err else 0

def time_str():
    return "%s_%s" % (datetime.date.today().strftime("%Y%m%d"), datetime.datetime.now().time().strftime("%H%M%S"))

def create_dir_for_file(file):
    file = file.replace("\\" if os.sep == "/" else "/", os.sep)
    while file.find(os.sep + os.sep) != -1:
        file = file.replace(os.sep + os.sep, os.sep)
    while file.find("." + os.sep) == 0:
        file = file.replace("." + os.sep, "")
    if file.endswith('\0'):
        file = file[:len(file)-1]

    start = 0
    while True:
        end = file.find(os.sep, start)
        if end == -1:
            break
        dir = file[:end]
        if not os.access(dir, os.F_OK):
            os.mkdir(dir)
        elif os.path.isfile(dir):
            print("Error, '%s' is file, can not create dir!" % dir)
        start = end + 1

    overwrite = True
    if (not overwrite) and os.access(file, os.F_OK):
        file = file + "_%s" % (time_str())
    return file

def client_task(sk, sk_addr, save_dir):
    client_tag = "[%s:%s]" % (sk_addr[0], sk_addr[1])
    print("%s connect" % (client_tag))
    total = 0

    sk.settimeout(120)
    recv_data = sk_recv_len(sk, 12)
    if not recv_data:
        sk.close()
        return

    magic,tag,length = struct.unpack("III", recv_data)
    print("%s magic=%d, tag=%d, len=%d" % (client_tag, magic, tag, length))
    if magic != tag_magic:
        sk.close()
        return

    if tag == tag_sync_version:
        recv_data = sk_recv_len(sk, 4)
        if recv_data:
            version, = struct.unpack("I", recv_data)
            print("%s sync version: %d" % (client_tag, version))
            send_tag_u32(sk, tag, version)
    elif tag == tag_open_file_for_write:
        recv_data = sk_recv_len(sk, length)
        if recv_data:
            file = create_dir_for_file(os.path.join(save_dir, recv_data.decode("utf-8")))
            print("%s create file: %s" % (client_tag, file))
            try:
                with open(file, "wb") as fo:
                    send_tag_u32(sk, tag, 0)
                    while fo:
                        recv_data = sk_recv(sk)
                        if not recv_data:
                            break
                        ret = fo.write(recv_data)
                        if ret is None: #python2.7
                            ret = len(recv_data)
                        if ret <= 0:
                            print("%s write ret %d " % (client_tag, ret))
                            break
                        total += ret
            except Exception as e:
                print("%s open(%s) " % (client_tag, file), e)
                send_tag_u32(sk, tag, sys._getframe().f_lineno)
        else:
            send_tag_u32(sk, tag, sys._getframe().f_lineno)

    print("%s disconnect, total: %d" % (client_tag, total))
    sk.close()

def server(port, save_dir):
    sk = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sk.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, True)
    try:
        sk.bind(("", port))
    except Exception as e:
        print(e)
        return
    sk.listen(16)
    while True:
        try:
            client, client_address= sk.accept()
        except KeyboardInterrupt as e:
            print(e)
            break
        except Exception as e:
            print(e)
            break
        t = Thread(target=client_task, args=(client, client_address, save_dir))
        t.start()
    sk.close()

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-s',
                            help='run in server mode',
                            action="store_true",
                            default=True,
                            required=False)
    parser.add_argument('-c',
                            help='run in client mode, connecting to <host>',
                            default=None,
                            required=False)
    parser.add_argument('-p',
                            help='server port to listen on/connect to',
                            default="9000",
                            required=False)
    parser.add_argument('-f',
                            help='file/dir list upload to server or dir to save file',
                            default=os.curdir,
                            required=False)

    args = parser.parse_args(sys.argv[1:])

    if args.c:
        print("Connecting to host %s, port %s" % (args.c, args.p))
        exit(send_file_list(args.c, int(args.p), args.f))
    elif args.s:
        with open(os.path.join(args.f, time_str() + ".log"), "wb") as fo:
            fo.close()
        print("Server listening on TCP port %s, save to dir '%s'" % (args.p, os.path.abspath(args.f)))
        server(int(args.p), args.f)
    else:
        print("%s [-s|-c host] [-p port]" % sys.argv[0])
