/*
    Copyright 2023 Quectel Wireless Solutions Co.,Ltd

    Quectel hereby grants customers of Quectel a license to use, modify,
    distribute and publish the Software in binary form provided that
    customers shall have no right to reverse engineer, reverse assemble,
    decompile or reduce to source code form any portion of the Software.
    Under no circumstances may customers modify, demonstrate, use, deliver
    or disclose any portion of the Software in source code form.
*/

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#ifndef __QUECTEL_QLOG_H
#define __QUECTEL_QLOG_H
#include <string.h>
#include <unistd.h>
#include <inttypes.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <time.h>
#include <signal.h>
#include <assert.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <poll.h>
#include <netinet/in.h>
#include <pthread.h>
#include <dirent.h>
#include <sys/ioctl.h>
#include <linux/version.h>
#if LINUX_VERSION_CODE > KERNEL_VERSION(2, 6, 20)
#include <linux/usb/ch9.h>
#else
#include <linux/usb_ch9.h>
#endif
#include <linux/usbdevice_fs.h>

typedef unsigned int uint32_t;
#define TFTP_F "tftp:"
#define FTP_F  "ftp:"

#ifndef MIN
#define MIN(x,y)	(((x) < (y)) ? (x) : (y))
#endif
#ifndef MAX
#define MAX(x,y)	(((x) < (y)) ? (y) : (x))
#endif
#define safe_close_fd(_fd) do { if (_fd != -1) { int tmpfd = _fd; _fd = -1; close(tmpfd); }} while(0)

typedef struct {
    int (*serial_open)(const char *port_name);
    int (*init_filter)(int fds[], int fd_num, const char *cfg);
    int (*clean_filter)(int fd);
    int (*logfile_init)(int logfd, int port_index, unsigned logfile_seq);
    size_t (*logfile_save)(int logfd, const void *buf, size_t size, int port_index);
    int (*logfile_close)(int logfd);
    const char *(*logfile_suffix)(int port_index);
} module_ops_t;

extern module_ops_t mdm_qlog_ops;
extern module_ops_t asr_qlog_ops;
extern module_ops_t unisoc_qlog_ops;
extern module_ops_t unisoc_exx00u_qlog_ops;
extern module_ops_t mtk_qlog_ops;
extern module_ops_t eigen_qlog_ops;
extern module_ops_t sony_qlog_ops;

extern int g_is_asr_chip;
extern int g_is_unisoc_chip;
extern int g_is_unisoc_exx00u_chip;
extern int g_is_eigen_chip;
extern int g_is_usb_disconnect;
extern int g_donot_split_logfile;
extern int use_qmdl2_v2;
extern int use_diag_qdss;
extern int use_diag_dpl;
extern int tty2tcp_sockfd;
extern unsigned g_rx_log_count;
extern unsigned qlog_exit_requested;
extern int qlog_continue;
extern int tftp_block_size;

typedef enum {
    SAVELOG_TO_UNKNOW,
    SAVELOG_TO_LOCAL_DISK,
    SAVELOG_TO_DEV_NULL,
    SAVELOG_TO_TTY2TCP,
    SAVELOG_TO_TFTP_SERVER,
    SAVELOG_TO_FTP_SERVER,
    SAVELOG_TO_TCP_SERVER,
    SAVELOG_TO_QTCP_SERVER,
} SAVELOG_TO_E;

#define SAVELOG_SUPPORT_LOG 1
#define SAVELOG_SUPPORT_DUMP 2
#define SAVELOG_SUPPORT_SPLIT 4

typedef struct _SAVELOG_TO_T {
    union {
        struct {
            char logdir[256];
        } local;
        struct {
            int port;
        } tty2tcp;
        struct {
            char ip[64];
        } tftp_server;
        struct {
            char ip[64];
            char user[64];
            char pass[64];
        } ftp_server;
        struct {
            char ip[64];
            int port;
        } tcp_server;
    };
} SAVELOG_TO_T;

#define FEATURE_SUPPORT_LOG      0x1
#define FEATURE_SUPPORT_DUMP   0x2
#define FEATURE_NOT_SPLIT_LOG   0x4

typedef struct {
    const char *name;
    unsigned int feature;
    int (*init)(int fds[], int num, SAVELOG_TO_T *to);
    void (*deinit)(void);
    int (*logfile_create)(const char *fullname, int port_index, long filesize);
    int (*logfile_init)(int logfd, int port_index);
    size_t (*logfile_save)(int logfd, const void *buf, size_t size);
    int (*logfile_close)(int logfd);
    void (*logfile_delete)(const char *fullname);
} savelog_ops_t;

extern const savelog_ops_t savelog_local_disk_ops;
extern const savelog_ops_t savelog_dev_null_ops;
extern const savelog_ops_t savelog_tty2tcp_ops;
extern const savelog_ops_t savelog_tftp_server_ops;
extern const savelog_ops_t savelog_ftp_server_ops;
extern const savelog_ops_t savelog_tcp_server_ops;
extern const savelog_ops_t savelog_qtcp_server_ops;
extern const savelog_ops_t *gp_savelog_ops;

extern ssize_t asr_send_cmd(int fd, const unsigned char *buf, size_t size);
extern ssize_t mdm_send_cmd(int fd, const unsigned char *buf, size_t size, int sync);
extern int qlog_create_file_in_logdir(const char *filename, long file_size);
extern size_t qlog_get_filesize_in_logidr(const char *filename);
extern int qlog_create_dir_in_logdir(const char *dirname);

extern uint16_t qlog_le16 (uint16_t v16);
extern uint32_t qlog_le32 (uint32_t v32);
extern uint64_t qlog_le64 (uint64_t v64);
extern ssize_t qlog_poll_write(int fd, const void *buf, size_t size, unsigned timeout_mesc);
extern ssize_t qlog_poll_read(int fd,  void *pbuf, size_t size, unsigned timeout_msec);
extern int qlog_poll_out(int fd, int timeout_msec);
extern size_t qlog_logfile_save(int logfd, const void *buf, size_t size);
extern int qlog_logfile_close(int logfd);

extern unsigned qlog_msecs(void);
extern int qlog_avail_space_for_dump(const char *dir, long need_MB);
#define qlog_raw_log(fmt, arg... ) do { unsigned msec = qlog_msecs(); printf("\r[%03u.%03u] " fmt,  msec/1000, msec%1000, ## arg); fflush(stdout);} while (0)
#define qlog_dbg(fmt, arg... ) do { unsigned msec = qlog_msecs(); printf("[%03u.%03u] " fmt,  msec/1000, msec%1000, ## arg); fflush(stdout);} while (0)
#define unused_result_write(_fd, _buf, _count) do { if (write(_fd, _buf, _count) == -1) {} } while (0)
extern int sahara_catch_dump(int port_fd, const char *dump_dir, int do_reset);
extern int unisoc_catch_dump(int usbfd, int ttyfd, const char *dump_dir, const char* (*qlog_time_name)(int));
extern int asr_catch_dump(int ttyfd, const char *dump_dir);

struct ql_usb_interface_info {
    uint8_t bInterfaceNumber;
    uint8_t bInterfaceClass;
    uint8_t bInterfaceSubClass;
    uint8_t bInterfaceProtocol;
    uint8_t bNumEndpoints;
    uint8_t ep_in;
    uint8_t ep_out;
};

enum {
    MDM_QDSS,
    MDM_ADPL,
    RG500U_LOG,
    RG500U_NMEA,
    EC200U_AP,
};

struct ql_usb_device_info {
    int idVendor;
    int idProduct;
    int bNumInterfaces;
    int busnum;
    int devnum;
    int major;
    int minor;
    int bcdDevice;
    int hardware; // 0 ~ usb, 'p' ~ pcie, 'u' - uart

    int dm_major;
    int dm_minor;
    char devname[32];
    char usbdevice_pah[256];
    char ttyDM[32];
    char ttyGENERAL[32]; //for all
    char ttyTHIRD[32]; //for dpl

    struct ql_usb_interface_info dm_intf;
    struct ql_usb_interface_info general_intf;
    struct ql_usb_interface_info third_intf;
    int general_type;
    int third_type;
};

#define RX_URB_SIZE (16*1024) //16KB for catch mdm dump
#define QLOG_BUF_SIZE (64*1024) //TTYB_DEFAULT_MEM_LIMIT 65536 -> (640 * 1024UL) 7ab57b76ebf632bf2231ccabe26bea33868118c6
#define MAX_USB_DEV 8
#define QLOG_LOG_NUM 4
extern struct ql_usb_device_info s_usb_device_info[];


extern int ql_match_dm_device(const char *devname, struct ql_usb_device_info *ql_dev);
extern int ql_find_quectel_modules(void);
extern int ql_usbfs_open_interface(const struct ql_usb_device_info *usb_dev, int intf);
extern int ql_usbfs_read(int usbfd, int ep_in, void *pbuf, unsigned len);
extern int ql_usbfs_write(int usbfd, int ep_out, const void *pbuf, unsigned len);

extern int drv_is_asr(int idProduct, int idVendor);
extern int drv_is_asr(int idProduct, int idVendor);
extern int drv_is_unisoc(int idProduct, int idVendor);
extern int drv_is_unisoc_exx00u(int idProduct, int idVendor);
extern int drv_is_mtk(int idProduct, int idVendor);
extern int drv_is_eigen(int idProduct, int idVendor);
extern size_t kfifo_write(int idx, const void *buf, size_t size);
extern void kfifo_free(int idx);
extern int kfifo_alloc(int fd);
extern int kfifo_idx(int fd);
extern void kfifo_init(void);
extern void mdm_reset_global_variables(void);
extern const char * qlog_time_name(int type);
extern const char *basename(const char *fullname);
#endif
