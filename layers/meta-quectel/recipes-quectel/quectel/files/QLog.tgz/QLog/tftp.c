/*
    Copyright 2023 Quectel Wireless Solutions Co.,Ltd

    Quectel hereby grants customers of Quectel a license to use, modify,
    distribute and publish the Software in binary form provided that
    customers shall have no right to reverse engineer, reverse assemble,
    decompile or reduce to source code form any portion of the Software.
    Under no circumstances may customers modify, demonstrate, use, deliver
    or disclose any portion of the Software in source code form.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <errno.h>
#include <poll.h>
#include <assert.h>
#include <stdio.h>
#include <fcntl.h>
#include "qlog.h"

extern const char *g_tftp_server_ip;
extern unsigned qlog_msecs(void);
extern int tftp_block_size;

/* opcodes we support */
#define TFTP_RRQ   1
#define TFTP_WRQ   2
#define TFTP_DATA  3
#define TFTP_ACK   4
#define TFTP_ERROR 5
#define TFTP_OACK  6

#define TFTP_MAX_RETRY  12
#define TFTP_TIME_RETRY 200

struct tftp_packet{
    uint16_t cmd;
    union{
        uint16_t code;
        uint16_t block;
        // For a RRQ and WRQ TFTP packet
        char filename[2];
    };
    uint8_t data[512];
};

struct tftp_data_packet {
    uint16_t cmd;
    uint16_t block;
    uint8_t data[16384];
};

// Socket fd this client use.
static struct sockaddr_in tftp_server;

#define N_DATA 1 // 4 get 10MB/s, 8 get 20MB/s
struct q_tftp_request {
    int index;
    int sock;
    int pipe[2];
    struct sockaddr_in sender;
    socklen_t  addr_len;
    int kfifo_idx;
    unsigned int closed;
    pthread_t tid;
    char file[256];
    struct tftp_data_packet tx_pkt;
    struct tftp_packet rx_pkt;
};

static struct q_tftp_request q_tftp_clients[QLOG_LOG_NUM];

static int tftp_socket(void) {
    int sock, reuse_addr = 1;

    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
    if (sock == -1) {
        qlog_dbg("%s socket, errno: %d (%s)\n", __func__, errno, strerror(errno));
        return -1;
    }
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &reuse_addr,sizeof(reuse_addr));

    return sock;
}

static int tftp_send_data_pkt(int sock, struct tftp_data_packet *tx_pkt, uint16_t block, int size, struct sockaddr_in *to);
static void * tftp_write_thread(void *arg) {
    struct q_tftp_request *q_req = (struct q_tftp_request *)arg;
    int save_fd = -1, pipe_fd = q_req->pipe[1];
    uint16_t tx_block = 1;
    int tx_size = 0;
    int re_send = 0;
    int wait_ack = 0;
    size_t total_len = 0;
    size_t total_resend = 0;
    size_t total_reack = 0;

    //dbg("%s enter\n", __func__);
    //save_fd = open(q_req->file, O_CREAT | O_WRONLY | O_TRUNC, 0444); //md5sum

    while (1) {
        int ret;
        struct pollfd pollfds[2] = {{q_req->sock, POLLIN, 0}, {pipe_fd, POLLIN, 0}};

#if 0
        qlog_dbg("tftp[%d] %s wait_ack=%d, tx_size=%d, re_send=%d, pipe_hangup=%d\n",
            q_req->index, wait_ack, tx_size, re_send, pipe_hangup);
#endif
        if (wait_ack) {
            if (re_send)
                tftp_send_data_pkt(q_req->sock, &q_req->tx_pkt, tx_block, tx_size, &q_req->sender);
        }
        else if (pipe_fd == -1 || tx_size == tftp_block_size) {
            tftp_send_data_pkt(q_req->sock, &q_req->tx_pkt, tx_block, tx_size, &q_req->sender);
            wait_ack = 1;
        }

        //dbg("%s poll n = %d!\n", __func__, n);
        do  {
            ret = poll(pollfds, wait_ack ? 1 : (pipe_fd == -1 ? 1 : 2), wait_ack ? TFTP_TIME_RETRY : 6000);
        } while ((ret < 0) && (errno == EINTR));

        if (ret <= 0) {
            if (wait_ack && re_send++ < TFTP_MAX_RETRY) {
                continue;
            }
            qlog_dbg("tftp[%d] poll=%d, wait_ack=%d, re_send=%d\n", q_req->index, ret, wait_ack, re_send);
            goto _out;
        }

        if (pollfds[0].revents & POLLIN) {
            ret = recv(q_req->sock, &q_req->rx_pkt, sizeof(struct tftp_packet), MSG_DONTWAIT);
            //qlog_dbg("tftp[%d] recv = %d, %d, %d!\n", q_req->index, ret, ntohs(q_req->rx_pkt.cmd), ntohs(q_req->rx_pkt.block));
            if (ret >= 4 && ntohs(q_req->rx_pkt.cmd) == TFTP_ACK) {
                uint16_t rx_block = ntohs(q_req->rx_pkt.block);

                if (tx_block == rx_block) {
                    total_len += tx_size;
                    total_resend += re_send;
                    wait_ack = 0;
                    re_send = 0;
                    tx_block++;
                    if (tx_size < tftp_block_size) {
                        goto _out;
                    }
                    tx_size = 0;
                }
                else {
                    total_reack++;
                    //qlog_dbg("tftp[%d] wait_ack:%d, block: tx:%u / rx:%u\n", q_req->index, wait_ack, tx_block, rx_block);
                    if (!wait_ack && rx_block == 0 && total_len == 0) { //if no data transfer in 1 second, tftp server will auto hangup connection
                        qlog_dbg("tftp[%d] close by server for not send first data in 1 second!\n", q_req->index);
                        goto _out;
                    }
                }
            }
            else if (ret >= 4 && ntohs(q_req->rx_pkt.cmd) == TFTP_ERROR) {
                qlog_dbg("tftp[%d] Error code: %d, message: '%s'\n", q_req->index, ntohs(q_req->rx_pkt.code), q_req->rx_pkt.data);
                goto _out;
            }            
            else {
                qlog_dbg("tftp[%d] read_sock=%d, errno: %d (%s)\n", q_req->index, ret, errno, strerror(errno));
                goto _out;
            }
        }
        else if (pollfds[0].revents & (POLLERR | POLLHUP)) {
            goto _out;
        }

        if (pollfds[1].revents & POLLIN) {
            ret = read(pipe_fd, q_req->tx_pkt.data + tx_size, tftp_block_size - tx_size);
            //dbg("%s read = %d!\n", __func__, ret);
            if (ret > 0) {
                if (save_fd != -1)
                    assert(write(save_fd, q_req->tx_pkt.data + tx_size, ret) == ret);
                tx_size += ret;
            }
            else {
                pipe_fd = -1;
                if (ret != 0 || errno != 0)
                    qlog_dbg("tftp[%d] read_pipe=%d, errno: %d (%s)\n", q_req->index, ret, errno, strerror(errno));
            }
        }
        else if (pollfds[1].revents & (POLLERR | POLLHUP)) {
            pipe_fd = -1;
        }
    }

_out:
    q_req->closed = 1;
    if (save_fd != -1) {
        close(save_fd);
    }

    if (total_resend || total_reack)
        qlog_dbg("%s exit with len=%zd, re_send=%zd, re_ack=%zd\n", __func__, total_len, total_resend, total_reack);
    return NULL;
}

static int tftp_write_request(const char *filename, int port_index, long tsize) {
    struct tftp_packet tx_pkt;
    int wait_ack;
    int ret, sock = -1, size;
    char *charp;
    struct sockaddr_in sender;
    socklen_t  addr_len = sizeof(sender);
    struct q_tftp_request *q_req = NULL;
    int i;

    (void)port_index;
    for (i=0; i<QLOG_LOG_NUM; i++)
    {
        if (q_tftp_clients[i].sock == -1) {
            q_req = &q_tftp_clients[i];
            q_tftp_clients[i].pipe[0] = -1;
            q_tftp_clients[i].pipe[1] = -1;
            break;
        }
    }

    if (q_req == NULL) {
        qlog_dbg("%s no free client\n", __func__);
        goto out;
    }

    qlog_dbg("%s filename=%s, tsize=%ld\n", __func__, filename, tsize);
    filename = basename(filename);

    sock = tftp_socket();
    if (sock < 0)
        goto out;

    memset(&tx_pkt, 0, sizeof(tx_pkt));
    tx_pkt.cmd = htons(TFTP_WRQ);
    charp = (char *)tx_pkt.data; //tx_pkt->filename to avoid [-Wformat-overflow=]
    if (tsize)
        size = snprintf(charp, sizeof(tx_pkt.data), "%.256s%c%s%c%s%c%d%c%s%c%ld%c", filename, 0, "octet", 0, "blksize", 0, tftp_block_size, 0, "tsize", 0, tsize, 0);
    else
        size = snprintf(charp, sizeof(tx_pkt.data), "%.256s%c%s%c%s%c%d%c", filename, 0, "octet", 0, "blksize", 0, tftp_block_size, 0);
    if (size < 0 || (size_t)size >= sizeof(tx_pkt.data)) {
        qlog_dbg("%s request too long (%d), errno: %d (%s)\n", __func__, size, errno, strerror(errno));
        safe_close_fd(sock);
        goto out;
    }
    /* nothing to move: charp already aliases tx_pkt.data */

    for(wait_ack = 0; wait_ack < TFTP_MAX_RETRY; wait_ack++) {
        struct pollfd pollfds[1] = {{sock, POLLIN, 0}};

        ret = sendto(sock, &tx_pkt, size + 2, 0, (struct sockaddr*)&tftp_server, sizeof(tftp_server));
        if (ret == -1) {
            qlog_dbg("%s sendto=%d, errno: %d (%s)\n", __func__, ret, errno, strerror(errno));
            q_req->sock = -1;
            goto out;
        }

        do  {
            ret = poll(pollfds, 1, TFTP_TIME_RETRY);
        } while ((ret < 0) && (errno == EINTR));

        if (ret <= 0) {
            qlog_dbg("%s poll=%d, errno: %d (%s)\n", __func__, ret, errno, strerror(errno));
            continue;
        }

        ret = recvfrom(sock, &tx_pkt, sizeof(struct tftp_packet), MSG_DONTWAIT, (struct sockaddr *)&sender, &addr_len);
        if (ret >= 4 && tx_pkt.cmd == htons(TFTP_OACK)) {
            strncpy(q_req->file, filename, sizeof(q_req->file));
            q_req->sock = sock;
            q_req->sender = sender;
            q_req->addr_len = addr_len;
            if (socketpair(AF_LOCAL, SOCK_STREAM, 0, q_req->pipe)) {
                qlog_dbg("%s socketpair, errno: %d (%s)\n", __func__, errno, strerror(errno));
                q_req->sock = -1;
                goto out;
            }

            if (pthread_create(&q_req->tid, NULL, tftp_write_thread, q_req)) {
                qlog_dbg("%s pthread_create, errno: %d (%s)\n", __func__, errno, strerror(errno));
                q_req->sock = -1;
                goto out;
            }
            goto out;
        }
        else if (ret >= 4 && tx_pkt.cmd == htons(TFTP_ERROR)) {
             qlog_dbg("TFTP_ERROR, code: %d, message: '%s'\n", ntohs(tx_pkt.code), tx_pkt.data);
             goto out;
        }
        else {
            qlog_dbg("%s recvfrom=%d, errno: %d (%s)\n", __func__, ret, errno, strerror(errno));
            goto out;
        }
    }

out:
    if (q_req && q_req->sock != -1) {
#if 0
        int size = 0;
        socklen_t socklen = 4;

        if (!getsockopt(q_req->pipe[0], SOL_SOCKET, SO_RCVBUF, &size, &socklen))
            qlog_dbg("recv buf size is %d\n", size);
        if (!getsockopt(q_req->pipe[0], SOL_SOCKET, SO_SNDBUF,  &size, &socklen))
            qlog_dbg("send buf size is %d\n", size);
#endif

//sahara write 512KB one time, but tftp only read 16KB one time, 
//so even kfifo has avail space, we also will drop data
        //q_req->kfifo_idx = kfifo_alloc(q_req->pipe[0]); 
        q_req->closed = 0;
        return q_req->pipe[0];
    }
    safe_close_fd(sock);
    if (q_req) {
        q_req->sock = -1;
        safe_close_fd(q_req->pipe[0]);
        safe_close_fd(q_req->pipe[1]);
    }
    return -1;
}

static int tftp_close_request(int sockfd) {
    int i;
    struct q_tftp_request *q_req = NULL;

    if (sockfd == -1)
        return -1;

    for (i=0; i<QLOG_LOG_NUM; i++)
    {
        if (q_tftp_clients[i].pipe[0] == sockfd) {
            q_req = &q_tftp_clients[i];

            close(q_req->pipe[0]);
            if (q_req->kfifo_idx != -1) {
                kfifo_free(q_req->kfifo_idx);
                q_req->kfifo_idx = -1;
            }
            pthread_join(q_req->tid, NULL);
            q_req->pipe[0] = -1;
            safe_close_fd(q_req->sock);
            safe_close_fd(q_req->pipe[1]);
            break;
        }
    }

    if (!q_req)
        qlog_dbg("%s not this sockfd %d\n", __func__, sockfd);
    return -1;
}

static size_t tftp_logfile_save(int sockfd, const void *buf, size_t size) {
    int i;
    struct q_tftp_request *q_req = NULL;
    int ret = size;

    if (sockfd == -1)
        return -1;

    for (i=0; i<QLOG_LOG_NUM; i++)
    {
        if (q_tftp_clients[i].pipe[0] == sockfd) {
            q_req = &q_tftp_clients[i];

            if (q_req->closed) {
                if (q_req->closed++ < 10) {
                    qlog_dbg("tftp[%d] drop log for tftp closed!\n", q_req->index);
                }
            }
            else {
                if (q_req->kfifo_idx != -1)
                    ret = kfifo_write(q_req->kfifo_idx, buf, size);
                else
                    ret = qlog_poll_write(sockfd, buf, size, TFTP_TIME_RETRY*TFTP_MAX_RETRY);
            }
            break;
        }
    }

    return ret;
}

static int tftp_send_data_pkt(int sock, struct tftp_data_packet *tx_pkt, uint16_t block, int size, struct sockaddr_in *to) {
    int ret;
    socklen_t addr_len = sizeof(struct sockaddr_in);

    //qlog_dbg("%s send = %d!\n", __func__, size);
    tx_pkt->cmd = htons(TFTP_DATA);
    tx_pkt->block = htons(block);

    ret = sendto(sock, tx_pkt, size + 4, 0, (struct sockaddr *)to, addr_len);
    if (ret == -1) {
        qlog_dbg("%s sendto=%d, errno: %d (%s)\n", __func__, ret, errno, strerror(errno));
    }

    return ret;
}

static int tftp_test_server(int fds[], int num, SAVELOG_TO_T *to) {
    int sock;
    int i;
    const char *serv_ip = to->tftp_server.ip;

    (void)fds;
    (void)num;
    for (i=0; i<QLOG_LOG_NUM; i++) {
        q_tftp_clients[i].index = i;
        q_tftp_clients[i].sock = -1;
        q_tftp_clients[i].pipe[0] = -1;
        q_tftp_clients[i].pipe[1] = -1;
        q_tftp_clients[i].kfifo_idx = -1;
    }

    tftp_server.sin_family = AF_INET;
    tftp_server.sin_port = htons(69);
    inet_pton(AF_INET, serv_ip, &(tftp_server.sin_addr.s_addr));

    sock = tftp_write_request("qlog_tftp_test_blksize", 0, 0);
    if (sock > 0) {
        int size = strlen(serv_ip);
        int retval = write(sock, (void *)serv_ip, size);

        tftp_close_request(sock);
        if (retval == size) {
           qlog_dbg("%s %s OK!\n", __func__, serv_ip);
           return 0;
        }
    }

    qlog_dbg("%s %s FAIL!\n", __func__, serv_ip);
    return -1;
}

const savelog_ops_t savelog_tftp_server_ops = {
    .name = "tftp",
    .feature = FEATURE_SUPPORT_DUMP,
    .init = tftp_test_server,
    .logfile_create = tftp_write_request,
    .logfile_close = tftp_close_request,
    .logfile_save = tftp_logfile_save,
};
