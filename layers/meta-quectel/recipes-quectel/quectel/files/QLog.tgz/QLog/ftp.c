/*
    Copyright 2023 Quectel Wireless Solutions Co.,Ltd

    Quectel hereby grants customers of Quectel a license to use, modify,
    distribute and publish the Software in binary form provided that
    customers shall have no right to reverse engineer, reverse assemble,
    decompile or reduce to source code form any portion of the Software.
    Under no circumstances may customers modify, demonstrate, use, deliver
    or disclose any portion of the Software in source code form.
*/

#include "qlog.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <errno.h>
#include <poll.h>
#include <assert.h>
#include <fcntl.h>
#include <ctype.h>
#include <netinet/ip.h>

extern int tcp_connect(const char *server_ip, int tcp_port);
extern unsigned qlog_msecs(void);
#define FTP_BUF_SIZE 1024

struct q_ftp_tag {
    int server_fd;
    int sockfd;
    int index;
    int kfifo_idx;
    char buf[FTP_BUF_SIZE];
};

struct q_ftp_tag q_ftp_t[QLOG_LOG_NUM];

static const char *g_ftp_server_ip;
static const char *g_ftp_server_usr;
static const char *g_ftp_server_pass;

static void ftp_die(const char *msg, char *buf)
{
    char *cp = buf; /* buf holds peer's response */

    /* Guard against garbage from remote server */
    while (*cp >= ' ' && *cp < '\x7f')
        cp++;
    *cp = '\0';
    qlog_dbg("unexpected server response%s%s: %s\n",(msg ? " to " : ""), (msg ? msg : ""), buf);
    //exit(-1); //debugging
}

static int ftp_cmd(const char *s1, const char *s2, int server_fd, char *buf)
{
    int n, len;

    qlog_dbg("cmd > %s %s\n", s1, s2);

    if (s1) {
        snprintf(buf, 1024, (s2 ? "%s %s\r\n" : "%s %s\r\n"+3),s1, s2);
        if (write(server_fd, buf, strlen(buf)) != (int)strlen(buf))
            return 0;
    }

    do {
        len = read(server_fd, buf, FTP_BUF_SIZE - 2);
        if (len <= 0) {  //ftp connect error or timeout
            strcpy(buf, "EOF"); /* for ftp_die */
            ftp_die(NULL, buf);
            return 0;
        }
        else {
            buf[len] = 0;
        }
    } while (!isdigit(buf[0]) || (buf[3] != ' ' &&  buf[3] != '-'));

    for (n = 4; n < len; n++) {
        if (buf[n] == '\r' || buf[n] == '\n')
            buf[n] = ' ';
    }
    //qlog_dbg("cmd < %s\n", buf);

    buf[3] = '\0';
    n = atoi(buf);
    buf[3] = ' ';
    return n;
}

static void ftp_quit(void)
{
    int i;
    for (i=0; i<QLOG_LOG_NUM; i++)
    {
        struct q_ftp_tag *ftp_client = &q_ftp_t[i];

        if (ftp_client->server_fd == -1)
            continue;

        if (ftp_cmd(NULL, NULL, ftp_client->server_fd, ftp_client->buf) != 226) {
            ftp_die(NULL, ftp_client->buf);
        }

        if (ftp_cmd("QUIT", NULL, ftp_client->server_fd, ftp_client->buf) != 221) {
            ftp_die("QUIT", ftp_client->buf);
        }

        safe_close_fd(ftp_client->server_fd);
    }
}

static int ftp_login(const char *ftp_server, const char *user, const char *password, char *buf)
{
    /* Connect to the command socket */
    int server_fd = tcp_connect(ftp_server, 21);
    if (server_fd == -1) {
        return -1;
    }

    if (ftp_cmd(NULL, NULL, server_fd, buf) != 220) {
        ftp_die(NULL, buf);
        goto _out;
    }

    /*  Login to the server */
    switch (ftp_cmd("USER", user, server_fd, buf)) {
    case 230:
        break;
    case 331:
        if (ftp_cmd("PASS", password, server_fd, buf) != 230) {
            ftp_die("PASS", buf);
            goto _out;
        }
    break;
    default:
        ftp_die("USER", buf);
        goto _out;
    }

    if (ftp_cmd("TYPE I", NULL , server_fd, buf) != 200) {
        ftp_die("TYPE I", buf);
        goto _out;
    }

    return server_fd;
_out:
    close(server_fd);
    return -1;
}

static int  parse_pasv_epsv(char *buff)
{
    char *ptr;
    int port;

    if (buff[2] == '7' /* "227" */) {
        /* Response is "227 garbageN1,N2,N3,N4,P1,P2[)garbage]"
         * Server's IP is N1.N2.N3.N4 (we ignore it)
         * Server's port for data connection is P1*256+P2 */
        ptr = strrchr(buff, ')');
        if (ptr) *ptr = '\0';

        ptr = strrchr(buff, ',');
        if (!ptr) return -1;
        *ptr = '\0';
        port = atoi(ptr + 1);

        ptr = strrchr(buff, ',');
        if (!ptr) return -1;
        *ptr = '\0';
        port += atoi(ptr + 1) * 256;
    } else {
        /* Response is "229 garbage(|||P1|)"
         * Server's port for data connection is P1 */
        ptr = strrchr(buff, '|');
        if (!ptr) return -1;
        *ptr = '\0';

        ptr = strrchr(buff, '|');
        if (!ptr) return -1;
        *ptr = '\0';
        port = atoi(ptr + 1);
    }

    return port;
}

static int ftp_send(const char *ftp_server, const char *filename, int server_fd, char *buf) {
    int port_num;
    int sockfd = -1;
    int response;

    if (ftp_cmd("PASV", NULL, server_fd, buf) != 227) {
        ftp_die("PASV", buf);
        return -1;
    }

    port_num = parse_pasv_epsv(buf);
    if (port_num < 0) {
        ftp_die("PASV", buf);
        return -1;
    }

    sockfd = tcp_connect(ftp_server, port_num);
    if (sockfd < 0) {
        ftp_die("PASV", buf);
        return -1;
    }

    response = ftp_cmd("STOR", filename, server_fd, buf);
    switch (response) {
    case 125:
    case 150:
        break;
    default:
        ftp_die("STOR", buf);
        close(sockfd);
        return -1;
    }

    return sockfd;
}

static int ftp_write_request(const char *filename, int port_index, long filesize)
{
    int i;
    struct q_ftp_tag *ftp_client = NULL;

    (void)port_index;
    (void)filesize;

    for (i=0; i<QLOG_LOG_NUM; i++)
    {
        if (q_ftp_t[i].sockfd == -1) {
            ftp_client = &q_ftp_t[i];
            break;
        }
    }
    if (ftp_client == NULL)
        goto out;

    if (ftp_client->server_fd == -1)
    {
        ftp_client->server_fd = ftp_login(g_ftp_server_ip, g_ftp_server_usr, g_ftp_server_pass, ftp_client->buf);
        if (ftp_client->server_fd == -1) {
            goto out;
        }
    }
    else
    {
        if (ftp_cmd(NULL, NULL, ftp_client->server_fd, ftp_client->buf) != 226) {
            ftp_die(NULL,  ftp_client->buf);
            return -1;
        }
    }

    filename = basename(filename);
    ftp_client->sockfd = ftp_send(g_ftp_server_ip, filename, ftp_client->server_fd,  ftp_client->buf);
out:
    if (ftp_client->sockfd != -1)
        ftp_client->kfifo_idx= kfifo_alloc(ftp_client->sockfd);
    return  ftp_client->sockfd;
}

static int ftp_close_request(int sockfd) {
    int i;

    if (sockfd == -1)
        return -1;

    for (i=0; i<QLOG_LOG_NUM; i++)
    {
        if (q_ftp_t[i].sockfd == sockfd) {
            safe_close_fd(q_ftp_t[i].sockfd);
            if (q_ftp_t[i].kfifo_idx != -1) {
                kfifo_free(q_ftp_t[i].kfifo_idx);
                q_ftp_t[i].kfifo_idx = -1;
            }
            break;
        }
    }

    return -1;
}

static size_t ftp_logfile_save(int sockfd, const void *buf, size_t size) {
    int i;
    struct q_ftp_tag *ftp_client = NULL;
    int ret = size;

    if (sockfd == -1)
        return -1;

    for (i=0; i<QLOG_LOG_NUM; i++)
    {
        if (q_ftp_t[i].sockfd == sockfd) {
            ftp_client = &q_ftp_t[i];
            if (ftp_client->kfifo_idx != -1)
                ret = kfifo_write(ftp_client->kfifo_idx, buf, size);
            else
                ret = qlog_poll_write(sockfd, buf, size, 200);
            break;
        }
    }

    if (!ftp_client)
        qlog_dbg("%s not this sockfd %d\n", __func__, sockfd);
    return ret;
}

static int ftp_test_server(int fds[], int num, SAVELOG_TO_T *to) {
    int i, sock;
    const char *serv_ip = to->ftp_server.ip;

    (void)fds;
    (void)num;

    g_ftp_server_ip = to->ftp_server.ip;
    g_ftp_server_usr = to->ftp_server.user;
    g_ftp_server_pass = to->ftp_server.pass;

    for (i=0; i<QLOG_LOG_NUM; i++) {
        q_ftp_t[i].server_fd = -1;
        q_ftp_t[i].sockfd= -1;
        q_ftp_t[i].index = i;
        q_ftp_t[i].kfifo_idx= -1;
   }

    sock = ftp_write_request("qlog_ftp_test_file", 0, 0);
    if (sock > 0) {
        int size = strlen(serv_ip);
        int retval = write(sock, (void *)serv_ip, size);

        ftp_close_request(sock);
        if (retval == size) {
           qlog_dbg("%s %s OK!\n", __func__, serv_ip);
           return 0;
        }
    }

    qlog_dbg("%s %s FAIL!\n", __func__, serv_ip);
    return -1;
}

const savelog_ops_t savelog_ftp_server_ops = {
    .name = "ftp",
    .feature = FEATURE_SUPPORT_LOG | FEATURE_SUPPORT_DUMP,
    .init = ftp_test_server,
    .deinit = ftp_quit,
    .logfile_create = ftp_write_request,
    .logfile_close = ftp_close_request,
    .logfile_save = ftp_logfile_save,
};
