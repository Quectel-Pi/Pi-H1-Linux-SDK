/*
    Copyright 2023 Quectel Wireless Solutions Co.,Ltd

    Quectel hereby grants customers of Quectel a license to use, modify,
    distribute and publish the Software in binary form provided that
    customers shall have no right to reverse engineer, reverse assemble,
    decompile or reduce to source code form any portion of the Software.
    Under no circumstances may customers modify, demonstrate, use, deliver
    or disclose any portion of the Software in source code form.
*/

#include "qlog.h"
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <sys/types.h>

unsigned int inet_addr(const char *cp);
char *inet_ntoa(struct in_addr in);

#define CACHE_SIZE (2*1024*1024)
static const size_t cache_step = (256*1024);
static pthread_mutex_t kfifo_mutex = PTHREAD_MUTEX_INITIALIZER;

#ifdef CACHE_SIZE
struct __kfifo {
    int fd;
    size_t in;
    size_t out;
    size_t size;
    void *data;
};

static int __kfifo_write(struct __kfifo *fifo, const void *buf, size_t size) {
    void *data;
    size_t unused, len;
    ssize_t nbytes;
    int fd = fifo->fd;

    if (fifo->out == fifo->in) {
        nbytes = qlog_poll_write(fd, buf, size, 0);

        if (nbytes > 0) {
            if ((size_t)nbytes == size) {
                return 1;
            } else {
                buf += nbytes;
                size -= nbytes;
            }
        }
        else if (errno == ECONNRESET) {
            qlog_dbg("TODO: ECONNRESET\n");
            return 0;
        }
        else if (errno == EIO) {
            qlog_dbg("TODO: EIO\n");
            return 0;
        }
        else if (errno != EAGAIN) {
        }
    }

    unused = fifo->size - fifo->in;
    if (unused < size && size < (unused + fifo->out)) {
        memmove(fifo->data, fifo->data + fifo->out, fifo->in - fifo->out);
        fifo->in -=  fifo->out;
        fifo->out = 0;
    }

    unused = fifo->size - fifo->in;
    if (unused < size && fifo->size < CACHE_SIZE) {
        data = malloc(fifo->size + cache_step);

        if (data) {
            qlog_dbg("cache[fd=%d] size %zd -> %zd KB\n", fd, fifo->size/1024, (fifo->size + cache_step)/1024);
            if (fifo->data) {
                len = fifo->in - fifo->out;
                if (len)
                    memcpy(data, fifo->data + fifo->out, len);
                free(fifo->data);
            }

            fifo->in -=  fifo->out;
            fifo->out = 0;
            fifo->size += cache_step;
            fifo->data = data;
        }
    }

    unused = fifo->size - fifo->in;
    if (unused < size) {
        static size_t drop = 0;
        static unsigned slient_msec = 0;
        unsigned now = qlog_msecs();

        drop += size;
        if ((slient_msec+2000) < now) {
            qlog_dbg("cache[fd=%d] full, total drop %zd\n", fd, drop);
            slient_msec = now;
        }
    }
    else {
        memcpy(fifo->data + fifo->in, buf, size);
        fifo->in += size;
    }

    len = fifo->in - fifo->out;
    if (len) {
        nbytes = qlog_poll_write(fd, fifo->data + fifo->out, len, 0);

        if (nbytes > 0) {
            fifo->out += nbytes;

            if (fifo->out == fifo->in) {
                fifo->in = 0;
                fifo->out = 0;
            }
        }
        else if (errno == ECONNRESET) {
            qlog_dbg("TODO: ECONNRESET\n");
            return 0;
        }
        else if (errno == EIO) {
            qlog_dbg("TODO: EIO\n");
            return 0;
        }
        else if (errno != EAGAIN) {
        }
    }

    return 1;
}

#define FIFO_NUM 12
static struct __kfifo kfifo[FIFO_NUM];

void kfifo_init(void) {
    int i;

    pthread_mutex_lock(&kfifo_mutex);
    for (i = 0; i < FIFO_NUM; i++) {
        kfifo[i].fd = -1;
        kfifo[i].in = kfifo[i].out = kfifo[i].size = 0;
        kfifo[i].data = NULL;
    }
    pthread_mutex_unlock(&kfifo_mutex);
}

int kfifo_alloc(int fd) {
    int idx = 0;
    int flags;

    if (fd == -1)
        return fd;

    pthread_mutex_lock(&kfifo_mutex);
    for (idx = 0; idx < FIFO_NUM; idx++) {
        if (kfifo[idx].fd == -1)
            break;
    }

    if (idx == FIFO_NUM) {
        pthread_mutex_unlock(&kfifo_mutex);
        qlog_dbg("No Free FIFO for fd = %d\n", fd);
        return -1;
    }

    kfifo[idx].fd = fd;
    kfifo[idx].in = kfifo[idx].out = 0;
    pthread_mutex_unlock(&kfifo_mutex);

    flags = fcntl(fd, F_GETFL);
    if (flags != -1)
        fcntl(fd, F_SETFL, flags | O_NONBLOCK);

    //qlog_dbg("%s [%d] = %d\n", __func__, idx, fd);
    return idx;
}

/* attention: even fd is able-poll-out, but if write size is too larger than avail space of kfifo, also can cause drop data
    fifo is not recomment to use when catch dump, for read dump speed from modem is very larger than tcp/udp socket write speed
*/
size_t kfifo_write(int idx, const void *buf, size_t size) {
    if (idx < 0 ||  idx >= FIFO_NUM)
        return 0;
    return __kfifo_write(&kfifo[idx], buf, size) ? size : 0;
}

void kfifo_free(int idx) {
    if (idx < 0 || idx >= FIFO_NUM)
        return;
    //qlog_dbg("%s [%d] = %d\n", __func__, idx, kfifo[idx].fd);
    pthread_mutex_lock(&kfifo_mutex);
    kfifo[idx].fd = -1;
    kfifo[idx].in = kfifo[idx].out = 0;
    pthread_mutex_unlock(&kfifo_mutex);
}

int kfifo_idx(int fd) {
    int idx = 0;

    if (fd == -1)
        return fd;

    for (idx = 0; idx < FIFO_NUM; idx++) {
        if (kfifo[idx].fd == fd)
            break;
    }

    if (idx == FIFO_NUM) {
        return -1;
    }

    return idx;
}
#endif

static int wait_tcp_client_connect(int tcp_port) {
    int sockfd, n, connfd;
    struct sockaddr_in serveraddr;
    struct sockaddr_in clientaddr;
    int reuse_addr = 1;
    size_t sin_size;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1)
    {
        qlog_dbg("Create socket fail!\n");
        return 0;
    }

    memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serveraddr.sin_port = htons(tcp_port);

    qlog_dbg("Starting the TCP server(%d)...\n", tcp_port);

    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &reuse_addr,sizeof(reuse_addr));

    n = bind(sockfd, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
    if (n == -1)
    {
        qlog_dbg("bind fail! errno: %d\n", errno);
        close(sockfd);
        return 0;
    }
    qlog_dbg("bind OK!\n");

    n = listen(sockfd, 1);
    if (n == -1)
    {
        qlog_dbg("listen fail! errno: %d\n", errno);
        close(sockfd);
        return 0;
    }
    qlog_dbg("listen OK! and Waiting the TCP Client...\n");

    sin_size = sizeof(struct sockaddr_in);
    connfd = accept(sockfd, (struct sockaddr *)&clientaddr, (socklen_t *)&sin_size);
    close(sockfd);
    if (connfd == -1)
    {
        qlog_dbg("accept fail! errno: %d\n", errno);
        return -1;
    }

    fcntl(connfd, F_SETFL, fcntl(connfd, F_GETFL) | O_NONBLOCK);

    qlog_dbg("TCP Client %s:%d connect tcp port %d, connfd = %d\n",
        inet_ntoa(clientaddr.sin_addr), clientaddr.sin_port, tcp_port, connfd);

    return connfd;
}

int tty2tcp_sockfd = -1;
static int tty2tcp_ttyfd = -1;
static int tty2tcp_tcpport = 9000;
static int tty2tcp_forward_fds_cnt = 0;
struct q_tty2tcp_request {
    int fd;
    int sock;
    unsigned closed;
    int kfifo_idx;
    int index;
};
struct q_tty2tcp_request tty2tcp_clients[QLOG_LOG_NUM];

static void tty2tcp_mark_close(int sock) {
    int i;

    for (i = 0; i < tty2tcp_forward_fds_cnt; i++) {
        if (tty2tcp_clients[i].sock == sock) {
            tty2tcp_clients[i].closed = 1;
            break;
        }
    }
}

static void *tcp_sock_read_Loop(void *arg) {
    void *rbuf;
    const size_t rbuf_size = (4*1024);
    int i;
    struct q_tty2tcp_request *q_req;

    (void)arg;
    rbuf = malloc(rbuf_size);
    if (rbuf == NULL) {
          qlog_dbg("Fail to malloc rbuf_size=%zd, errno: %d (%s)\n", rbuf_size, errno, strerror(errno));
          return NULL;
    }

    for (i = 0; i < tty2tcp_forward_fds_cnt; i++) {
        q_req = &tty2tcp_clients[i];
        q_req->sock = wait_tcp_client_connect(tty2tcp_tcpport + i);
        if (q_req->sock == -1)
            goto _out;
        q_req->kfifo_idx = kfifo_alloc(q_req->sock);
        if (i == 0)
            tty2tcp_sockfd = q_req->sock;
    }

    while (qlog_exit_requested == 0) {
        ssize_t rc, wc;
        int ret;
        struct pollfd pollfds[QLOG_LOG_NUM];
        int n = 0;

        for (i = 0; i < tty2tcp_forward_fds_cnt; i++) {
            q_req = &tty2tcp_clients[i];
            if (q_req->sock != -1 && q_req->closed == 0) {
                pollfds[n].fd = q_req->sock;
                pollfds[n].events = POLLIN;
                pollfds[n].revents = 0;
                n++;
            }
        }

        if (n == 0)
            break;

        do {
            ret = poll(pollfds, n, -1);
        } while (ret == -1 && errno == EINTR && qlog_exit_requested == 0);

        if (ret <= 0) {
            qlog_dbg("poll(ttyfd) =%d, errno: %d (%s)\n", ret, errno, strerror(errno));
            break;
        }

        for (i = 0; i <  n; i++) {
            int fd = pollfds[i].fd;

            if (pollfds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                qlog_dbg("fd = %d revents = %04x\n", fd, pollfds[0].revents);
                tty2tcp_mark_close(fd);
                continue;
            }

            if (!(pollfds[i].revents & (POLLIN)))
                continue;

            rc = read(fd, rbuf, rbuf_size);
            if (rc <= 0) {
                qlog_dbg("sockfd = %d recv %zd Bytes. maybe terminae by peer!\n", fd, rc);
                tty2tcp_mark_close(fd);
                continue;
            }
            else if (fd == tty2tcp_sockfd){
                if (g_is_asr_chip)
                    wc = asr_send_cmd(tty2tcp_ttyfd, rbuf, rc);
                else if (g_is_unisoc_chip)
                    wc = qlog_poll_write(tty2tcp_ttyfd, rbuf, rc, 1000);
                else if (g_is_unisoc_exx00u_chip)
                    wc = qlog_poll_write(tty2tcp_ttyfd, rbuf, rc, 1000);
                else if (g_is_eigen_chip)
                    wc = qlog_poll_write(tty2tcp_ttyfd, rbuf, rc, 1000);
                else
                    wc = mdm_send_cmd(tty2tcp_ttyfd, rbuf, rc, 0);

                if (wc != rc) {
                    //qlog_dbg("ttyfd write fail %zd/%zd, break\n", wc, rc);
                    //break;
                }
            }
            else
            {
                qlog_dbg("recv %zd Bytes from fd = %d\n", rc, fd);
            }
        }
    }

_out:
    free(rbuf);
    tty2tcp_sockfd = -1;
    for (i = 0; i < tty2tcp_forward_fds_cnt; i++) {
        tty2tcp_clients[i].closed = 1;
    }
    qlog_dbg("%s exit\n", __func__);

    return NULL;
}

int tty2tcp_init(int fds[], int num, SAVELOG_TO_T *to) {
    pthread_t tid;
    pthread_attr_t attr;
    int i;

    for (i = 0; i < QLOG_LOG_NUM && i < num; i++) {
        tty2tcp_clients[i].fd = i < num ? fds[i] : -1;
        tty2tcp_clients[i].sock = -1;
        tty2tcp_clients[i].kfifo_idx = -1;
        tty2tcp_clients[i].closed = 0;
   }
    tty2tcp_forward_fds_cnt = num;

    tty2tcp_ttyfd = fds[0];
    if (to->tty2tcp.port > 0)
        tty2tcp_tcpport = to->tty2tcp.port;

    pthread_attr_init (&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&tid, &attr, tcp_sock_read_Loop, NULL);

    while (qlog_exit_requested == 0) {
        for (i = 0; i < tty2tcp_forward_fds_cnt; i++) {
            if (tty2tcp_clients[i].fd == -1) {
                break;
           }
        }
        if (i == tty2tcp_forward_fds_cnt)
            break;
        sleep(1);
    }

    //pthread_attr_destroy(&attr);
    return 0;
}

static int tty2tcp_logfile_create(const char *fullname, int port_index, long filesize) {
    (void)fullname;
    (void)filesize;
    if (port_index >= tty2tcp_forward_fds_cnt) {
        qlog_dbg("%s %d / %d!\n", __func__, port_index, tty2tcp_forward_fds_cnt);
        return -1;
    }
    return tty2tcp_clients[port_index].sock;
}

static size_t tty2tcp_logfile_save(int sockfd, const void *buf, size_t size) {
    int i;
    int ret = size;

    for (i = 0; i < tty2tcp_forward_fds_cnt; i++) {
        struct q_tty2tcp_request *q_req = &tty2tcp_clients[i];

        if (q_req->sock == sockfd) {
            if (q_req->closed) {
                if (q_req->closed++ < 10) {
                    qlog_dbg("tty2tcp[%d] drop log for tcp connection closed!\n", q_req->index);
                }
            }
            if (q_req->kfifo_idx != -1)
                ret = kfifo_write(q_req->kfifo_idx, buf, size);
            else
                ret = qlog_poll_write(sockfd, buf, size, 200);
            break;
        }
    }

    return ret;
}

static int tty2tcp_logfile_close(int sockfd) {
    int i;

    for (i = 0; i < tty2tcp_forward_fds_cnt; i++) {
        if (tty2tcp_clients[i].sock == sockfd) {
            safe_close_fd(tty2tcp_clients[i].sock);
            if (tty2tcp_clients[i].kfifo_idx != -1) {
                kfifo_free(tty2tcp_clients[i].kfifo_idx);
                tty2tcp_clients[i].kfifo_idx = -1;
            }
            break;
        }
    }
    return 0;
}

const savelog_ops_t savelog_tty2tcp_ops = {
    .name = "tty2tcp",
    .feature = FEATURE_SUPPORT_LOG | FEATURE_NOT_SPLIT_LOG,
    .init = tty2tcp_init,
    .logfile_create = tty2tcp_logfile_create,
    .logfile_save = tty2tcp_logfile_save,
    .logfile_close = tty2tcp_logfile_close,
};

static int g_tcp_server_port;
static char *g_tcp_server_ip;
static int tcp_client_fd[QLOG_LOG_NUM];

static int tcp_server_logfile_close(int sockfd) {
    int i;

    for (i = 0; i < QLOG_LOG_NUM; i++) {
        if (sockfd == tcp_client_fd[i]) {
            safe_close_fd(tcp_client_fd[i]);
            break;
        }
    }
    return 0;
}

int tcp_connect(const char *server_ip, int tcp_port) {
    int sockfd, ret;
    struct sockaddr_in ser;

    sockfd = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
    if (sockfd <0) {
        qlog_dbg("%s(%s, %d) : error\n", __func__, server_ip, tcp_port);
        return -1;
    }

    memset(&ser,0,sizeof(ser));
    ser.sin_family = AF_INET;
    ser.sin_port = htons(tcp_port);
    ser.sin_addr.s_addr = inet_addr(server_ip);

    ret = connect(sockfd,(struct sockaddr *)&ser,sizeof(ser));
    if (ret == 0) {
        qlog_dbg("%s(%s %d)=%d\n", __func__, server_ip, tcp_port, sockfd);
    }
    else {
        qlog_dbg("%s(%s %d), errno:%d(%s)\n", __func__, server_ip, tcp_port, errno, strerror(errno));
        safe_close_fd(sockfd);
    }

    return sockfd;
}

static int tcp_server_logfile_create(const char *fullname, int port_index, long filesize)
{
    (void)fullname;
    (void)filesize;
    if (port_index < 0 || port_index >= QLOG_LOG_NUM)
        return -1;

    if (tcp_client_fd[port_index] != -1) {
        qlog_dbg("%s tcp_client_fd[%d]=%d has opend!\n",
            __func__, port_index, tcp_client_fd[port_index]);
        return -1;
    }

    tcp_client_fd[port_index] = tcp_connect(g_tcp_server_ip, g_tcp_server_port + port_index);
    return tcp_client_fd[port_index];
}

static int tcp_server_init(int fds[], int num, SAVELOG_TO_T *to) {
    int i;

    (void)fds;
    (void)num;
    g_tcp_server_ip = to->tcp_server.ip;
    g_tcp_server_port = to->tcp_server.port;

    for (i = 0; i < QLOG_LOG_NUM; i++) {
        tcp_client_fd[i] = -1;
    }
    return 1;
}

const savelog_ops_t savelog_tcp_server_ops = {
    .name = "tcp_client",
    .feature = FEATURE_SUPPORT_LOG | FEATURE_NOT_SPLIT_LOG,
    .init =  tcp_server_init,
    .logfile_create = tcp_server_logfile_create,
    .logfile_close = tcp_server_logfile_close,
};

static const uint32_t tag_magic = 95279527;
static const uint32_t tag_sync_version = 95270001;
static const uint32_t tag_open_file_for_write = 95270002;

struct qtcp_tlv {
    uint32_t magic;
    uint32_t tag;
    uint32_t len;
    uint32_t value;
};

struct qtcp_state {
    int sockfd;
};

struct qtcp_state qtcp_clients[QLOG_LOG_NUM];

static int qtcp_server_init(int fds[], int num, SAVELOG_TO_T *to) {
    int i, sockfd, ret;
    struct qtcp_tlv tx = {tag_magic, tag_sync_version, 4, 1};
    struct qtcp_tlv rx;

    (void)fds;
    (void)num;
    g_tcp_server_ip = to->tcp_server.ip;
    g_tcp_server_port = to->tcp_server.port;

    for (i = 0; i < QLOG_LOG_NUM; i++) {
        qtcp_clients[i].sockfd = -1;
    }

    sockfd = tcp_connect(g_tcp_server_ip, g_tcp_server_port);
    if (sockfd == -1)
        return -1;

    ret = write(sockfd, &tx, sizeof(tx));
    if (ret != sizeof(tx)) {
        qlog_dbg("%s write error: ret=%d, errno:%d(%s)\n", __func__, ret, errno, strerror(errno));
        close(sockfd);
        return -1;
    }
    ret = read(sockfd, &rx, sizeof(rx));
    if (ret != sizeof(rx)) {
        qlog_dbg("%s read error: ret=%d, errno:%d(%s)\n", __func__, ret, errno, strerror(errno));
        close(sockfd);
        return -1;
    }
    if (tx.magic != rx.magic || tx.tag != rx.tag ||tx.len != rx.len ||tx.value != rx.value) {
        qlog_dbg("%s un-match magic:%u/%u, tid:%u/%u, len:%u/%u, value:%u/%u\n",
            __func__, tx.magic, rx.magic, tx.tag, rx.tag, tx.len, rx.len, tx.value, rx.value);
        close(sockfd);
        return -1;
    }

    close(sockfd);
    return 0;
}

static int qtcp_server_logfile_create(const char *fullname, int port_index, long filesize)
{
    struct qtcp_state *q_req = NULL;
    int i, sockfd, ret;
    struct qtcp_tlv tx, rx;
    int name_len = strlen(fullname) + 1;

    (void)port_index;
    (void)filesize;
    for (i=0; i<QLOG_LOG_NUM; i++)
    {
        if (qtcp_clients[i].sockfd == -1) {
            q_req = &qtcp_clients[i];
            break;
        }
    }

    if (q_req == NULL) {
        qlog_dbg("%s no free client\n", __func__);
        return -1;
    }

    sockfd = tcp_connect(g_tcp_server_ip, g_tcp_server_port);
    if (sockfd == -1)
        return -1;

    tx.magic = qlog_le32(tag_magic);
    tx.tag = qlog_le32(tag_open_file_for_write);
    tx.len = qlog_le32(name_len);
    tx.value = 0;
    
    ret = write(sockfd, &tx, 12);
    if (ret != 12) {
        qlog_dbg("%s write error: ret=%d, errno:%d(%s)\n", __func__, ret, errno, strerror(errno));
        safe_close_fd(sockfd);
        return -1;
    }
    ret = write(sockfd, fullname, name_len);
    if (ret != name_len) {
        qlog_dbg("%s write error: ret=%d, errno:%d(%s)\n", __func__, ret, errno, strerror(errno));
        safe_close_fd(sockfd);
        return -1;
    }
    ret = read(sockfd, &rx, sizeof(rx));
    if (ret != (int)sizeof(rx)) {
        qlog_dbg("%s read error: ret=%d, errno:%d(%s)\n", __func__, ret, errno, strerror(errno));
        safe_close_fd(sockfd);
        return 0;
    }
    if (tx.magic != rx.magic || tx.tag != rx.tag ||4 != rx.len || 0 != rx.value) {
        qlog_dbg("%s un-match magic:%u/%u, tag:%u/%u, len:%u/%u, value:%u/%u\n",
            __func__, tx.magic, rx.magic, tx.tag, rx.tag, 4, rx.len, 0, rx.value);
        safe_close_fd(sockfd);
        return -1;
    }

    q_req->sockfd = sockfd;
    return sockfd;
}

static int qtcp_server_logfile_close(int sockfd) {
    int i;

    for (i = 0; i < QLOG_LOG_NUM; i++) {
        struct qtcp_state *q_req = &qtcp_clients[i];

        if (sockfd == q_req->sockfd) {
                safe_close_fd(q_req->sockfd);
            break;
        }
    }

    return 0;
}

static void qtcp_server_deinit(void) {
    int i;

    for (i = 0; i < QLOG_LOG_NUM; i++) {
        struct qtcp_state *q_req = &qtcp_clients[i];

        if (q_req->sockfd != -1) {
            safe_close_fd(q_req->sockfd);
        }
    }
}

const savelog_ops_t savelog_qtcp_server_ops = {
    .name = "qtcp_client",
    .feature = FEATURE_SUPPORT_LOG | FEATURE_SUPPORT_DUMP,
    .init =  qtcp_server_init,
    .deinit =  qtcp_server_deinit,
    .logfile_create = qtcp_server_logfile_create,
    .logfile_close = qtcp_server_logfile_close,
};

