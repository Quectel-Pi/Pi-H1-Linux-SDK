# HeartRateGame #

Demonstrates how to check a Bluetooth-connection, discover LE-devices, connect
to devices, discover services and finally connect to a heartrate-service.
The purpose of the game is increase the heartrate so much as possible in 60s.
Relax before starting the game. Don't be too nervous, it increases the heartrate!

